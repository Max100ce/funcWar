class Bonhomme {
	constructor(couleur) {
		skin: new Image(30, 30, src='../img/bonhomme' + couleur + 'Vie.png'),
		x: Math.floor(Math.random() * 250) + 50,
		y: Math.floor(Math.random() * 350) + 50
	}
}

function setupCanvas(nomJoueur1, nomJoueur2, couleurJoueur1, couleurJoueur2) {
	var ctx = document.getElementById('aireDeJeu').getContext('2d')

	var joueur1 = new Bonhomme(couleurJoueur1)

	console.log(joueur1.skin)
}